# Changelog


## v3.7.1

- FIX: Run CSS compatibility checks against both source and release Kanboard layouts


## v3.7.0

_(most recent changes are listed on top):_
- NEW: Add Light, Dark, and Automatic Colour Scheme Support - closes #25
- NEW: Add Responsive Mobile and Tablet Layouts
- FIX: Keep Comment Actions Available on Mobile Screens
- FIX: Reserve Red for Destructive and Urgent States
- FIX: Load Custom CSS After the Main Theme
- FIX: Restore Task Age, Assignee, and Priority Information
- FIX: Preserve FontSwitcher Control of Task Title Fonts
- FIX: Add Reduced-Motion and Forced-Colour Support
- FIX: Correct Undefined CSS Custom Properties
- FIX: Require and Test Kanboard 1.2.54 with PHP 8.2-8.5


## v3.6

_(most recent changes are listed on top):_
- FIX: Update Plugin Description to Mention FontSwitcher
- FIX: Remove `en_US` Translations - all code is in `en_US` anyway
- NEW: Add FontSwitcher Compatibility
- FIX: Remove Font Dependability - use FontSwitcher to change fonts to avoid local limitations
- FIX: Modal Close Button Display - fix hover effects
- FIX: Letter Spacing for `code`


## v3.5

_(most recent changes are listed on top):_
- NEW: Add Code Scanning Badge to README.md
- FIX: Code Scanning: CSS Fixes
- FIX: Code Scanning: Avoid Warnings
- FIX: Code Scanning: Delete Duplicates
- FIX: Code Scanning: Major CSS Fixes
- FIX: README Navigation Links for GitHub
- FIX: Code Scanning: Expected empty line before rule
- FIX: Code Scanning: Unexpected Unit
- FIX: Move Archived Releases to `Releases`
- FIX: Code Syntax - Unexpected leading zero
- FIX: Code Syntax in Translations
- FIX: Code Syntax in changelog.md
- FIX: Anchor Link Position
- FIX: Code Syntax
- FIX: changelog.md
- NEW: Add Footer Badges to README.md
- NEW: Add Section Navigation Links to README.md
- NEW: Add Badges to README.md
- FIX: Add README Page Navigation Links
- NEW: Add README Page Navigation Links
- FIX: Content Flow for README.md
- NEW: Create INSTALL.md
- NEW: Add Download Badge to README.md
- NEW: Stronger Alert Notification - also delay timeout to 10s instead of default 7s
- NEW: Move Alerts to The Top of Screen
- FIX: Task Sidebar Font Size
- FIX: Sidebar Indicator & Alignment
- FIX: Sidebar Font Weight
- FIX: Sidebar was too restrictive
- FIX: Alert - fixed alerts were auto-fading too
- FIX: Remove Duplicate Code


## v3.1

_(most recent changes are listed on top):_
- FIX: Remove Global Table Selector
- REVERT FIX: SVG Pointer Events Conflicting with Links - rely on plugins to code their svgs properly


## v3.0

_(most recent changes are listed on top):_
- Rename translations file
- Update translations
- Update screenshots - fixes #18
- Update plugin description
- NEW: Plugin Compatibility: [TemplateManager](https://github.com/aljawaid/TemplateManager)
- FIX: Modal Close Button Priority
- FIX: SVG Pointer Events Conflicting with Links
- NEW: Fix Modal Close Button Display - improve styling and make larger
- NEW: Plugin Compatibility: [ApplicationBranding](https://github.com/aljawaid/ApplicationBranding "ApplicationBranding - A plugin for Kanboard")
- NEW: Show Indicator in Dropdown Menus
- NEW: Save screen space in Application Settings
- NEW: Add Text Selection Matching Colour
- FIX: Remove `!important`


## v2.3

_(most recent changes are listed on top):_
- FIX: Remove Duplicate
- FIX: Page Header Margins
- FIX: Remove Unused Variables
- FIX: Rename CSS Variable
- FIX: Define the standard property `appearance` for compatibility
- FIX: Empty Rulesets
- FIX: Define the standard property `transform-origin` for compatibility
- Cleanup code
- FIX: Add Missing `border-radius` Variable
- FIX: Rename `border-radius` Variable
- Cleanup colour code syntax
- FIX: Remove Priority Box Shadow
- FIX: Merge Classes
- FIX: Margin and class target - fix `margin-top` - remove `!important`
- FIX: Remove Duplicate Code
- FIX: Filter Padding- make narrower, save space


## v2.2

_(most recent changes are listed on top):_
- FIX: Rename Folder - Folder Consistency
- FIX: Folder Consistency
- Update archive - remove git code
- Prepare 2023
- Fix and Add Transition Variable
- Fix for [ColorManager plugin](https://github.com/aljawaid/ColorManager/commit/29c3c9e894326288df42dc235b1b6503b1e347b7)
- Fix CSS Jumping Side Menu
- FIX: Box Shadow Variable


## v2.1

_(most recent changes are listed on top):_
- FIX: Wrong installed version when installing v2.0 (still showed as v1.5)
- General bug fixes and improvements


## v2.0

_(most recent changes are listed on top):_
- NEW: Mobile Improvements
- NEW: Animated Web Notification Icon
- Add rounding to field borders
- Make required field asterisk bigger
- FIX: #5 Label alignment in create new task is off thanks @peterk
- Compatibility with [Customizer](https://github.com/creecros/Customizer) plugin
- Compatibility with [Bak2TopBotm](https://github.com/creecros/Bak2topbotm) plugin
- Updated README.md file
- **Updated file structure (reinstall may be required)**
- Drop IE6 Compatibility
- Style Board Action Menu Icons
- Add Custom CSS File for Local Overrides
- FIX: Location for theme file #13
- FIX: Float titles inline for more compact board  thanks @gdmac
- FIX:  Collapsed Column #7 #8- thanks @TimoStahl
- NEW: Add Translations for Plugin Description
- Update License Copyright
- Prepare for design update
- Fix: added selector a:focus to the definition of a:hover thanks @auge8472
- Fix: Task limit highlight column thanks @creecros
- Add Plugin Compatibility
- FIX: #5 Label alignment in create new task is off
- NEW: Add rounding to field borders
- NEW: Make required field asterisk bigger
- Update install instructions to include Kanboard Plugin Directory
- Update README.md #4 thanks @schittli


## v1.5

_(most recent changes are listed on top):_
- Make page text pure black for easier reading
- Make links in task descriptions stand out
- Make inline code stand out
- Add to Kanboard Plugin Directory
- Add styling to blockquote text
- Renamed `style.css` to `kanboardcss.css` for easier reference during testing (reinstall of plugin maybe required)
- Hide scroll bars in board menu list
- Hide column titles (except the first one) on each swimlane Thanks [@Qrizzz](https://github.com/kanboard/kanboard/issues/3994)
- Make task titles bold in board view
- Make tooltip info circles bit bigger in board view
- Add clearer and slightly darker page headers
- Make alert notification clearer and deeper yellow


## v1.0

_(most recent changes are listed on top):_
- Relaunched based on style `v0.0.4`
- Restructured all files and folders
- Added `archive` folder for previous versions
- FIX: Board search bar was too large for KB `v1.2.5`
- Added `MIT` license file
- Updated plugin info (for plugin settings)


## v0.0.5

_(most recent changes are listed on top):_
- The blue heading from 0.0.3 is gone and quiet grey is implemented.
- Tasks has gotten more padding and margin for more space between everything (and font-size, width of colorstatus, etc.)
- Collapsed column has been minimized from 28px to 5px


## 0.0.4

_(most recent changes are listed on top):_
- Based on 0.0.3 but will be more colorful - mostly in cold blue


## v0.0.3

_(most recent changes are listed on top):_
- Changed theme to a lookup alike Gitlabs Issue board


## v0.0.2

_(most recent changes are listed on top):_
- Made ready for git clone to `plugins` folder


## v0.0.1

- Initial release

---

Read the full [**Changelog**](../master/changelog.md "See changes") or view the [**README**](../master/README.md "View README")
