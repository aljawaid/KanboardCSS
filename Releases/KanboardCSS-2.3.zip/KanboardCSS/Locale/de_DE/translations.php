<?php
return array(
  //
  // GENERAL
  //
  'This plugin adds a new style for the Kanboard user interface. As a polished theme for modern browsers using gradients and shades of blue and red, this theme refreshes the Kanboard interface to complement the user experience.' => 'Dieses Plugin fügt der Kanboard-Benutzeroberfläche einen neuen Stil hinzu. Als ausgefeiltes Design für moderne Browser mit Farbverläufen und Blau- und Rottönen aktualisiert dieses Design die Kanboard-Oberfläche, um das Benutzererlebnis zu ergänzen.',
);
