<?php
return array(
  //
  // GENERAL
  //
  'This plugin adds a new style for the Kanboard user interface. As a polished theme for modern browsers using gradients and shades of blue and red, this theme refreshes the Kanboard interface to complement the user experience.' => 'Ce plugin ajoute un nouveau style pour l\'interface utilisateur de Kanboard. En tant que thème raffiné pour les navigateurs modernes utilisant des dégradés et des nuances de bleu et de rouge, ce thème actualise l\'interface Kanboard pour compléter l\'expérience utilisateur.',
);
