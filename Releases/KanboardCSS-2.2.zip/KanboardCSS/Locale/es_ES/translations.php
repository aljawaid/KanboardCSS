<?php
return array(
  //
  // GENERAL
  //
  'This plugin adds a new style for the Kanboard user interface. As a polished theme for modern browsers using gradients and shades of blue and red, this theme refreshes the Kanboard interface to complement the user experience.' => 'Este complemento agrega un nuevo estilo para la interfaz de usuario de Kanboard. Como tema pulido para los navegadores modernos que utilizan degradados y tonos de azul y rojo, este tema actualiza la interfaz de Kanboard para complementar la experiencia del usuario.',
);
